-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 23, 2014 at 07:38 PM
-- Server version: 5.0.96
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `activist`
--

--
-- Dumping data for table `source`
--

INSERT INTO `source` (`sourceid`, `name`, `shortname`, `url`, `geo`) VALUES
(1, 'Централна Изборна Комисия', 'ЦИК', 'http://www.cik.bg/', '42.69672,23.32544'),
(2, 'Портал за обществени консултации', 'Strategy.bg', 'http://www.strategy.bg', '42.69789,23.32383'),
(3, 'Министерски съвет', 'МС', 'http://www.government.bg/', '42.69789,23.32383'),
(4, 'Народно събрание', 'НС', 'http://parliament.bg/', '42.69418,23.33259'),
(5, 'Комисия по досиетата', 'КомДос', 'http://www.comdos.bg/', '42.69757,23.33048'),
(6, 'Национална Електрическа Компания', 'НЕК', 'http://www.nek.bg/', '42.69849,23.32562'),
(7, 'Електроенергиен системен оператор', 'ЕСО', 'http://www.tso.bg/default.aspx/nachalo/bg', '42.67136,23.29552'),
(8, 'Конституционен съд', 'КС', 'http://constcourt.bg/', '42.69770,23.32498'),
(9, 'Висш съдебен съвет', 'ВСС', 'http://www.vss.justice.bg/', '42.70033,23.32191'),
(10, 'Министерство на регионалното развитие ', 'МРРБ', 'http://www.mrrb.government.bg/', '42.70288,23.33096'),
(11, 'Министерство на икономиката и енергетиката', 'МИЕ', 'http://www.mi.government.bg/', '42.72523,25.48154'),
(12, 'Агенция по обществените поръчки', 'АОП', 'http://www.aop.bg/', '42.69541,23.32387'),
(13, 'Прокуратура', 'Прокуратура', 'http://www.prb.bg/', '42.69552,23.32062'),
(14, 'Българска академия на науките', 'БАН', 'http://bas.bg', '42.69692,23.32803'),
(15, 'Българска народна банка', 'БНБ', 'http://bnb.bg/', '42.69684,23.32551'),
(16, 'Административен регистър', 'Админ.Регистър', 'http://ar2.government.bg/ras/index.html', '42.69789,23.32383'),
(17, 'Държавна агенция “Национална сигурност”', 'ДАНС', 'http://www.dans.bg/', '42.66424,23.31742'),
(18, 'Интерпол', 'Интерпол', 'http://www.interpol.int', '42.69118,23.32741'),
(19, 'Министерство на вътрешните работи', 'МВР', 'https://www.mvr.bg', '42.69129,23.32749'),
(20, 'Други', 'Други', NULL, NULL),
(21, 'Министерство на здравеопазването', 'МЗ', 'http://www.mh.government.bg/', '42.69584,23.32018'),
(22, 'Комисия за финансов надзор', 'КФН', 'http://www.fsc.bg/', '42.69915,23.32801');

--
-- Dumping data for table `s_bas`
--

INSERT INTO `s_bas` (`grad`, `geo`) VALUES
('Благоевград', '42.0109204,23.0905953'),
('Бургас', '42.4942274,27.4550161'),
('Варна', '43.2485263,27.9085149'),
('Велико Търново', '43.0820584,25.6321312'),
('Добрич', '43.5688397,27.8297415'),
('Пазарджик', '42.1889295,24.3324797'),
('Перник', '42.6083042,23.0421163'),
('Плевен', '43.4088034,24.6181'),
('Пловдив', '42.1419118,24.7498385'),
('Русе', '43.8485969,25.9535686'),
('Сливен', '42.6823429,26.3208862'),
('София', '42.6977149,23.3230598'),
('Стара Загора', '42.4247421,25.6257235'),
('Хасково', '41.9345727,25.5556639'),
('Шумен', '43.2712716,26.9360254'),
('Ямбол', '42.4837872,26.5107315');

--
-- Dumping data for table `s_retweet`
--

INSERT INTO `s_retweet` (`twitter`, `lasttweet`, `lastcheck`, `lastretweet`, `tw_rts`, `tw_fav`, `tw_num`) VALUES
('KGeorgievaEU', '524872548606304256', '2014-10-23 16:20:28', '2014-10-23 15:30:05', 10, 10, 1),
('BgPresidency', NULL, '2014-10-23 16:21:52', NULL, 0, 0, 0),
('EP_Bulgaria', '524519900426305536', '2014-10-23 16:21:53', NULL, 0, 0, 0),
('ECinBulgaria', '525198616341012480', '2014-10-23 16:20:27', '2014-10-23 15:30:24', 4, 4, 1),
('FandakovaY', '524516723383603200', '2014-10-23 16:21:54', NULL, 0, 0, 0),
('MFABulgaria', '520552848938246144', '2014-10-23 16:20:27', NULL, 0, 0, 0),
('evapaunova', '524949192113135616', '2014-10-23 16:20:28', '2014-10-23 15:42:40', 3, 8, 2),
('SvMalinov', NULL, '2014-10-23 16:21:52', NULL, 0, 0, 0);

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`lib`, `task`, `priority`, `delay`, `lastrun`, `active`) VALUES
('cik', 'cikSaobshteniq', 0, 0, NULL, 1),
('cik', 'cikResheniq', 0, 0, NULL, 1),
('cik', 'cikDnevenRed', 0, 0, NULL, 1),
('cik', 'cikJalbi', 0, 4, '2014-10-23 15:50:04', 1),
('cik', 'cikProtokol', 0, 4, '2014-10-23 15:50:04', 1),
('government', 'govZasedaniq', 0, 1, '2014-10-23 18:35:13', 1),
('government', 'govResheniq', 0, 2, '2014-10-23 18:00:03', 1),
('government', 'govSabitiq', 0, 0, NULL, 1),
('government', 'govDokumenti', 0, 1, '2014-10-23 18:35:13', 1),
('parliament', 'parlZakonoproekti', 0, 0, NULL, 1),
('parliament', 'parlParlamentarenKontrol', 0, 4, '2014-10-23 16:00:08', 1),
('min_mrrb', 'mrrb_Obqvi', 0, 1, '2014-10-23 18:35:17', 1),
('parliament', 'parlPlenarnoZasedanie', 0, 4, '2014-10-23 16:10:04', 1),
('parliament', 'parlZakoni', 0, 2, '2014-10-23 18:10:03', 1),
('parliament', 'parlDokumentiZala', 0, 1, '2014-10-23 19:00:05', 1),
('parliament', 'parlResheniq', 0, 2, '2014-10-23 18:10:04', 1),
('parliament', 'parlSabitiq', 0, 4, '2014-10-23 16:10:03', 1),
('parliament', 'parlDeklaracii', 0, 12, '2014-10-23 09:30:34', 1),
('comdos', 'comdosResheniq', 0, 4, '2014-10-23 15:50:05', 1),
('cik', 'cikPrincipniResheniq', 0, 6, '2014-10-23 15:50:04', 1),
('nek', 'nekSaobshteniq', 0, 12, '2014-10-23 09:30:33', 1),
('tso', 'tsoNovini', 0, 3, '2014-10-23 19:10:07', 1),
('tso', 'tsoSaobshteniq', 0, 3, '2014-10-23 19:10:07', 1),
('constcourt', 'constcourtNovini', 0, 1, '2014-10-23 18:35:11', 1),
('constcourt', 'constcourtSaobchteniq', 0, 1, '2014-10-23 18:35:12', 1),
('vss', 'vssDnevenRed', 0, 4, '2014-10-23 16:30:08', 1),
('vss', 'vssProtokol', 0, 4, '2014-10-23 16:30:09', 1),
('min_mrrb', 'mrrb_Informaciq', 0, 4, '2014-10-23 17:40:10', 1),
('min_mi', 'mi_Obqvi', 0, 1, '2014-10-23 18:35:17', 1),
('min_mi', 'mi_Aktivi', 0, 3, '2014-10-23 18:30:37', 1),
('min_mi', 'mi_Drugi', 0, 3, '2014-10-23 18:30:36', 1),
('bas', 'basZemetreseniq', 0, 0, NULL, 1),
('errorcheck', 'errorcheck', 0, 72, '2014-10-23 01:04:03', 1),
('prokuratura', 'prok_Novini', 0, 1, '2014-10-23 19:10:06', 1),
('prokuratura', 'prok_Dokumenti', 0, 3, '2014-10-23 18:20:04', 1),
('prokuratura', 'prok_Konkursi', 0, 12, '2014-10-23 09:30:34', 1),
('prokuratura', 'prok_Snimki', 0, 6, '2014-10-23 16:10:04', 1),
('government', 'govNovini', 0, 2, '2014-10-23 18:00:02', 1),
('vss', 'vssNovini', 0, 6, '2014-10-23 16:30:08', 1),
('bnb', 'bnb_Saobshtenia', 0, 0, NULL, 1),
('bnb', 'bnb_PlatejenBalans', 0, 8, '2014-10-23 12:20:02', 1),
('bnb', 'bnb_BrutenVanshenDalg', 0, 8, '2014-10-23 12:20:02', 1),
('bnb', 'bnb_ParichniDepositi', 0, 8, '2014-10-23 12:20:05', 1),
('bnb', 'bnb_KreditiDepositi', 0, 8, '2014-10-23 12:20:01', 1),
('bnb', 'bnb_LihvenaStatistika', 0, 8, '2014-10-23 12:20:02', 1),
('bnb', 'bnb_LizingoviDrujestva', 0, 8, '2014-10-23 12:20:02', 1),
('bnb', 'bnb_InvesticionniFondove', 0, 8, '2014-10-23 12:20:03', 1),
('bnb', 'bnb_KoreditiraneDrujestva', 0, 8, '2014-10-23 12:20:03', 1),
('bnb', 'bnb_ZastrahovatelnaDeinost', 0, 8, '2014-10-23 12:20:03', 1),
('adminreg', 'arKonkursi', 0, 24, '2014-10-23 12:00:05', 1),
('dans', 'dansInformaciq', 0, 1, '2014-10-23 18:35:13', 1),
('interpol', 'interpolIzcheznali', 1, 3, '2014-10-23 18:30:20', 1),
('interpol', 'interpolIzdirvani', 1, 3, '2014-10-23 18:30:34', 1),
('interpol', 'interpolProcessIzcheznali', 0, 1, '2014-10-23 18:35:13', 1),
('interpol', 'interpolProcessIzdirvani', 0, 1, '2014-10-23 18:35:13', 1),
('mvr', 'mvrNovini', 0, 1, '2014-10-23 19:00:05', 1),
('mvr', 'mvrKampanii', 0, 2, '2014-10-23 18:00:07', 1),
('mvr', 'mvrBlagoevgrad', 0, 2, '2014-10-23 17:50:03', 1),
('mvr', 'mvrBlagoevgradIzdirvani', 0, 2, '2014-10-23 19:30:02', 1),
('mvr', 'mvrVarna', 0, 2, '2014-10-23 19:30:06', 1),
('mvr', 'mvrVelikotarnovo', 0, 2, '2014-10-23 18:00:06', 1),
('mvr', 'mvrVelikotarnovoIzdirvani', 0, 2, '2014-10-23 17:50:03', 1),
('mvr', 'mvrVidin', 0, 2, '2014-10-23 19:30:04', 1),
('mvr', 'mvrVidinIzdirvani', 0, 2, '2014-10-23 19:10:02', 1),
('mvr', 'mvrVraca', 0, 2, '2014-10-23 18:50:03', 1),
('mvr', 'mvrVracaIzdirvani', 0, 2, '2014-10-23 19:30:04', 1),
('mvr', 'mvrGabrovo', 0, 2, '2014-10-23 19:10:04', 1),
('mvr', 'mvrGabrovoIzdirvani', 0, 2, '2014-10-23 18:50:14', 1),
('mvr', 'mvrKardjali', 0, 2, '2014-10-23 17:50:05', 1),
('mvr', 'mvrKardjaliIzdirvani', 0, 2, '2014-10-23 17:40:11', 1),
('mvr', 'mvrKiustendil', 0, 2, '2014-10-23 18:30:38', 1),
('mvr', 'mvrLovech', 0, 2, '2014-10-23 18:30:39', 1),
('mvr', 'mvrLovechIzdirvani', 0, 2, '2014-10-23 18:35:17', 1),
('mvr', 'mvrMontana', 0, 2, '2014-10-23 17:50:06', 1),
('mvr', 'mvrMontanaIzdirvani', 0, 2, '2014-10-23 18:00:04', 1),
('mvr', 'mvrPazardjik', 0, 2, '2014-10-23 17:40:11', 1),
('mvr', 'mvrPazardjikIzdirvani', 0, 2, '2014-10-23 19:30:04', 1),
('mvr', 'mvrPernik', 0, 2, '2014-10-23 18:20:03', 1),
('mvr', 'mvrPernikIzdirvani', 0, 2, '2014-10-23 18:50:03', 1),
('mvr', 'mvrPleven', 0, 2, '2014-10-23 18:50:06', 1),
('mvr', 'mvrPlevenIzdirvani', 0, 2, '2014-10-23 18:50:06', 1),
('mvr', 'mvrRazgrad', 0, 2, '2014-10-23 18:10:03', 1),
('mvr', 'mvrRuse', 0, 2, '2014-10-23 18:50:07', 1),
('mvr', 'mvrRuseIzdirvani', 0, 2, '2014-10-23 19:10:04', 1),
('mvr', 'mvrSilistra', 0, 2, '2014-10-23 19:10:05', 1),
('mvr', 'mvrSilistraIzdirvani', 0, 2, '2014-10-23 19:30:04', 1),
('mvr', 'mvrSliven', 0, 2, '2014-10-23 19:00:03', 1),
('mvr', 'mvrSlivenIzdirvani', 0, 2, '2014-10-23 19:30:05', 1),
('mvr', 'mvrSmolqn', 0, 2, '2014-10-23 19:00:03', 1),
('mvr', 'mvrSmolqnIzdirvani', 0, 2, '2014-10-23 19:10:06', 1),
('mvr', 'mvrSofiq', 0, 2, '2014-10-23 18:50:09', 1),
('mvr', 'mvrStaraZagora', 0, 2, '2014-10-23 18:50:13', 1),
('mvr', 'mvrStaraZagoraIzdirvani', 0, 2, '2014-10-23 19:00:04', 1),
('mvr', 'mvrTargovishte', 0, 2, '2014-10-23 19:20:03', 1),
('mvr', 'mvrHaskovo', 0, 2, '2014-10-23 19:20:04', 1),
('mvr', 'mvrShumen', 0, 2, '2014-10-23 18:00:03', 1),
('mvr', 'mvrShumenIzdirvani', 0, 2, '2014-10-23 19:00:04', 1),
('mvr', 'mvrQmbol', 0, 2, '2014-10-23 19:20:07', 1),
('mvr', 'mvrQmbolIzdirvani', 0, 2, '2014-10-23 17:40:11', 1),
('retweet', 'retweetAccounts', 0, 1, '2014-10-23 18:53:08', 1),
('mvr', 'mvrBurgas', 0, 2, '2014-10-23 19:20:07', 1),
('mvr', 'mvrPlovdiv', 0, 2, '2014-10-23 19:30:05', 1),
('min_mi', 'mi_Obsajdane', 0, 3, '2014-09-09 18:20:03', 0),
('min_mi', 'mi_Makrobiuletin', 0, 26, '2014-10-22 20:29:03', 1),
('min_mi', 'mi_Fininst', 0, 48, '2014-10-22 01:28:05', 1),
('min_mi', 'mi_KoncentraciqFin', 0, 48, '2014-10-22 07:21:06', 1),
('min_mh', 'mh_Saobshteniq', 0, 1, '2014-10-23 18:35:13', 1),
('min_mh', 'mh_Novini', 0, 1, '2014-10-23 18:35:15', 1),
('kfn', 'kfn_Novini', 0, 0, NULL, 1),
('kfn', 'kfn_Analizi', 0, 4, '2014-10-23 16:10:03', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
