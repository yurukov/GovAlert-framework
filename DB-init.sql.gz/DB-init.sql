-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 24, 2014 at 04:55 PM
-- Server version: 5.0.96
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `activist`
--

--
-- Dumping data for table `source`
--

REPLACE INTO `source` (`sourceid`, `name`, `shortname`, `url`, `geo`) VALUES
(1, 'Централна Изборна Комисия', 'ЦИК', 'http://www.cik.bg/', '42.69672,23.32544'),
(2, 'Портал за обществени консултации', 'Strategy.bg', 'http://www.strategy.bg', '42.69789,23.32383'),
(3, 'Министерски съвет', 'МС', 'http://www.government.bg/', '42.69789,23.32383'),
(4, 'Народно събрание', 'НС', 'http://parliament.bg/', '42.69418,23.33259'),
(5, 'Комисия по досиетата', 'КомДос', 'http://www.comdos.bg/', '42.69757,23.33048'),
(6, 'Национална Електрическа Компания', 'НЕК', 'http://www.nek.bg/', '42.69849,23.32562'),
(7, 'Електроенергиен системен оператор', 'ЕСО', 'http://www.tso.bg/default.aspx/nachalo/bg', '42.67136,23.29552'),
(8, 'Конституционен съд', 'КС', 'http://constcourt.bg/', '42.69770,23.32498'),
(9, 'Висш съдебен съвет', 'ВСС', 'http://www.vss.justice.bg/', '42.70033,23.32191'),
(10, 'Министерство на регионалното развитие ', 'МРРБ', 'http://www.mrrb.government.bg/', '42.70288,23.33096'),
(11, 'Министерство на икономиката и енергетиката', 'МИЕ', 'http://www.mi.government.bg/', '42.72523,25.48154'),
(12, 'Агенция по обществените поръчки', 'АОП', 'http://www.aop.bg/', '42.69541,23.32387'),
(13, 'Прокуратура', 'Прокуратура', 'http://www.prb.bg/', '42.69552,23.32062'),
(14, 'Българска академия на науките', 'БАН', 'http://bas.bg', '42.69692,23.32803'),
(15, 'Българска народна банка', 'БНБ', 'http://bnb.bg/', '42.69684,23.32551'),
(16, 'Административен регистър', 'Админ.Регистър', 'http://ar2.government.bg/ras/index.html', '42.69789,23.32383'),
(17, 'Държавна агенция “Национална сигурност”', 'ДАНС', 'http://www.dans.bg/', '42.66424,23.31742'),
(18, 'Интерпол', 'Интерпол', 'http://www.interpol.int', '42.69118,23.32741'),
(19, 'Министерство на вътрешните работи', 'МВР', 'https://www.mvr.bg', '42.69129,23.32749'),
(20, 'Други', 'Други', NULL, NULL),
(21, 'Министерство на здравеопазването', 'МЗ', 'http://www.mh.government.bg/', '42.69584,23.32018'),
(22, 'Комисия за финансов надзор', 'КФН', 'http://www.fsc.bg/', '42.69915,23.32801'),
(23, 'Национална агенция за приходите', 'НАП', 'http://www.nap.bg/', '42.69851,23.33379');

--
-- Dumping data for table `s_bas`
--

REPLACE INTO `s_bas` (`grad`, `geo`) VALUES
('Благоевград', '42.0109204,23.0905953'),
('Бургас', '42.4942274,27.4550161'),
('Варна', '43.2485263,27.9085149'),
('Велико Търново', '43.0820584,25.6321312'),
('Добрич', '43.5688397,27.8297415'),
('Пазарджик', '42.1889295,24.3324797'),
('Перник', '42.6083042,23.0421163'),
('Плевен', '43.4088034,24.6181'),
('Пловдив', '42.1419118,24.7498385'),
('Русе', '43.8485969,25.9535686'),
('Сливен', '42.6823429,26.3208862'),
('София', '42.6977149,23.3230598'),
('Стара Загора', '42.4247421,25.6257235'),
('Хасково', '41.9345727,25.5556639'),
('Шумен', '43.2712716,26.9360254'),
('Ямбол', '42.4837872,26.5107315');

--
-- Dumping data for table `s_retweet`
--

REPLACE INTO `s_retweet` (`twitter`, `lasttweet`, `lastcheck`, `lastretweet`, `tw_rts`, `tw_fav`, `tw_num`) VALUES
('KGeorgievaEU', '535806691242418177', '2014-11-24 13:48:51', '2014-11-23 08:50:05', 376, 411, 30),
('BgPresidency', '535359964014194688', '2014-11-24 12:45:35', '2014-11-20 10:50:03', 54, 58, 24),
('EP_Bulgaria', '534680343325188096', '2014-11-24 13:48:50', '2014-11-19 07:50:06', 33, 28, 11),
('ECinBulgaria', '536468694432768000', '2014-11-24 14:44:26', '2014-11-23 12:50:06', 60, 24, 11),
('FandakovaY', '532882249633763328', '2014-11-24 13:48:50', '2014-11-14 10:07:07', 20, 37, 7),
('MFABulgaria', '534671295133519872', '2014-11-24 14:44:26', '2014-11-19 08:50:13', 7, 3, 3),
('evapaunova', '535795640685838336', '2014-11-24 14:44:27', '2014-11-24 11:50:04', 143, 127, 41),
('SvMalinov', '532850488811982848', '2014-11-24 13:48:51', '2014-11-14 11:25:34', 1, 0, 1),
('tomislavdonchev', '533533080695603200', '2014-11-24 12:45:36', '2014-11-15 08:50:04', 0, 12, 3),
('IvailoKalfin', NULL, '2014-11-24 12:45:36', NULL, 0, 0, 0),
('BoykoBorissov', '535801862398943232', '2014-11-24 12:45:35', '2014-11-22 08:50:06', 20, 30, 8),
('MoskovPetar', '533666773766533121', '2014-11-24 14:44:27', '2014-11-16 10:50:05', 7, 28, 2);

--
-- Dumping data for table `task`
--

REPLACE INTO `task` (`lib`, `task`, `priority`, `delay`, `lastrun`, `active`) VALUES
('cik', 'cikSaobshteniq', 0, 0, NULL, 1),
('cik', 'cikResheniq', 0, 0, NULL, 1),
('cik', 'cikDnevenRed', 0, 0, NULL, 1),
('cik', 'cikJalbi', 0, 4, '2014-11-24 16:20:04', 1),
('cik', 'cikProtokol', 0, 4, '2014-11-24 16:07:45', 1),
('government', 'govZasedaniq', 0, 1, '2014-11-24 16:20:06', 1),
('government', 'govResheniq', 0, 2, '2014-11-24 16:40:02', 1),
('government', 'govSabitiq', 0, 0, NULL, 1),
('government', 'govDokumenti', 0, 1, '2014-11-24 16:20:06', 1),
('parliament', 'parlZakonoproekti', 0, 0, NULL, 1),
('parliament', 'parlParlamentarenKontrol', 0, 4, '2014-11-24 16:40:55', 1),
('min_mrrb', 'mrrb_Obqvi', 0, 1, '2014-11-24 16:28:03', 1),
('parliament', 'parlPlenarnoZasedanie', 0, 4, '2014-11-24 13:40:18', 1),
('parliament', 'parlZakoni', 0, 2, '2014-11-24 15:36:11', 1),
('parliament', 'parlDokumentiZala', 0, 1, '2014-11-24 16:44:24', 1),
('parliament', 'parlResheniq', 0, 2, '2014-11-24 16:44:24', 1),
('parliament', 'parlSabitiq', 0, 4, '2014-11-24 13:40:18', 1),
('parliament', 'parlDeklaracii', 0, 12, '2014-11-24 10:30:19', 1),
('comdos', 'comdosResheniq', 0, 4, '2014-11-24 16:20:05', 1),
('cik', 'cikPrincipniResheniq', 0, 6, '2014-11-24 16:20:03', 1),
('nek', 'nekSaobshteniq', 0, 12, '2014-11-24 10:30:18', 1),
('tso', 'tsoNovini', 0, 3, '2014-11-24 16:46:40', 1),
('tso', 'tsoSaobshteniq', 0, 3, '2014-11-24 16:46:41', 1),
('constcourt', 'constcourtNovini', 0, 1, '2014-11-24 16:20:05', 1),
('constcourt', 'constcourtSaobchteniq', 0, 1, '2014-11-24 16:20:05', 1),
('vss', 'vssDnevenRed', 0, 4, '2014-11-24 13:50:05', 1),
('vss', 'vssProtokol', 0, 4, '2014-11-24 13:50:05', 1),
('min_mrrb', 'mrrb_Informaciq', 0, 4, '2014-11-24 14:00:03', 1),
('min_mi', 'mi_Obqvi', 0, 1, '2014-11-24 16:27:58', 1),
('min_mi', 'mi_Aktivi', 0, 3, '2014-11-24 16:27:59', 1),
('min_mi', 'mi_Drugi', 0, 3, '2014-11-24 16:28:01', 1),
('bas', 'basZemetreseniq', 0, 0, NULL, 1),
('errorcheck', 'errorcheck', 0, 72, '2014-11-24 03:30:03', 1),
('prokuratura', 'prok_Novini', 0, 1, '2014-11-24 16:44:25', 1),
('prokuratura', 'prok_Dokumenti', 0, 3, '2014-11-24 16:46:39', 1),
('prokuratura', 'prok_Konkursi', 0, 12, '2014-11-24 11:40:13', 1),
('prokuratura', 'prok_Snimki', 0, 6, '2014-11-24 11:47:38', 1),
('government', 'govNovini', 0, 2, '2014-11-24 16:40:02', 1),
('vss', 'vssNovini', 0, 6, '2014-11-24 13:50:05', 1),
('bnb', 'bnb_Saobshtenia', 0, 0, NULL, 1),
('bnb', 'bnb_PlatejenBalans', 0, 8, '2014-11-24 12:20:01', 1),
('bnb', 'bnb_BrutenVanshenDalg', 0, 8, '2014-11-24 12:20:01', 1),
('bnb', 'bnb_ParichniDepositi', 0, 8, '2014-11-24 12:20:03', 1),
('bnb', 'bnb_KreditiDepositi', 0, 8, '2014-11-24 12:20:02', 1),
('bnb', 'bnb_LihvenaStatistika', 0, 8, '2014-11-24 12:20:02', 1),
('bnb', 'bnb_LizingoviDrujestva', 0, 8, '2014-11-24 12:20:02', 1),
('bnb', 'bnb_InvesticionniFondove', 0, 8, '2014-11-24 12:20:02', 1),
('bnb', 'bnb_KoreditiraneDrujestva', 0, 8, '2014-11-24 12:20:02', 1),
('bnb', 'bnb_ZastrahovatelnaDeinost', 0, 8, '2014-11-24 12:20:02', 1),
('adminreg', 'arKonkursi', 0, 24, '2014-11-24 12:00:05', 1),
('dans', 'dansInformaciq', 0, 1, '2014-11-24 16:20:06', 1),
('interpol', 'interpolIzcheznali', 1, 3, '2014-11-24 16:20:23', 1),
('interpol', 'interpolIzdirvani', 1, 3, '2014-11-24 16:20:34', 1),
('interpol', 'interpolProcessIzcheznali', 0, 1, '2014-11-24 16:27:53', 1),
('interpol', 'interpolProcessIzdirvani', 0, 1, '2014-11-24 16:20:34', 1),
('mvr', 'mvrNovini', 0, 1, '2014-11-24 16:40:17', 1),
('mvr', 'mvrKampanii', 0, 2, '2014-11-24 16:40:17', 1),
('mvr', 'mvrBlagoevgrad', 0, 2, '2014-11-24 16:40:18', 1),
('mvr', 'mvrBlagoevgradIzdirvani', 0, 2, '2014-11-24 16:40:18', 1),
('mvr', 'mvrVarna', 0, 2, '2014-11-24 16:40:19', 1),
('mvr', 'mvrVelikotarnovo', 0, 2, '2014-11-24 16:40:05', 1),
('mvr', 'mvrVelikotarnovoIzdirvani', 0, 2, '2014-11-24 16:40:19', 1),
('mvr', 'mvrVidin', 0, 2, '2014-11-24 16:40:54', 1),
('mvr', 'mvrVidinIzdirvani', 0, 2, '2014-11-24 15:35:53', 1),
('mvr', 'mvrVraca', 0, 2, '2014-11-24 15:35:54', 1),
('mvr', 'mvrVracaIzdirvani', 0, 2, '2014-11-24 16:40:16', 1),
('mvr', 'mvrGabrovo', 0, 2, '2014-11-24 15:35:56', 1),
('mvr', 'mvrGabrovoIzdirvani', 0, 2, '2014-11-24 15:35:56', 1),
('mvr', 'mvrKardjali', 0, 2, '2014-11-24 16:40:16', 1),
('mvr', 'mvrKardjaliIzdirvani', 0, 2, '2014-11-24 16:28:03', 1),
('mvr', 'mvrKiustendil', 0, 2, '2014-11-24 15:36:09', 1),
('mvr', 'mvrLovech', 0, 2, '2014-11-24 15:06:24', 1),
('mvr', 'mvrLovechIzdirvani', 0, 2, '2014-11-24 15:06:06', 1),
('mvr', 'mvrMontana', 0, 2, '2014-11-24 16:28:06', 1),
('mvr', 'mvrMontanaIzdirvani', 0, 2, '2014-11-24 16:40:05', 1),
('mvr', 'mvrPazardjik', 0, 2, '2014-11-24 16:28:06', 1),
('mvr', 'mvrPazardjikIzdirvani', 0, 2, '2014-11-24 16:28:04', 1),
('mvr', 'mvrPernik', 0, 2, '2014-11-24 16:40:06', 1),
('mvr', 'mvrPernikIzdirvani', 0, 2, '2014-11-24 15:20:08', 1),
('mvr', 'mvrPleven', 0, 2, '2014-11-24 15:06:23', 1),
('mvr', 'mvrPlevenIzdirvani', 0, 2, '2014-11-24 15:06:19', 1),
('mvr', 'mvrRazgrad', 0, 2, '2014-11-24 16:40:10', 1),
('mvr', 'mvrRuse', 0, 2, '2014-11-24 15:06:18', 1),
('mvr', 'mvrRuseIzdirvani', 0, 2, '2014-11-24 15:35:47', 1),
('mvr', 'mvrSilistra', 0, 2, '2014-11-24 15:36:10', 1),
('mvr', 'mvrSilistraIzdirvani', 0, 2, '2014-11-24 16:28:04', 1),
('mvr', 'mvrSliven', 0, 2, '2014-11-24 15:35:52', 1),
('mvr', 'mvrSlivenIzdirvani', 0, 2, '2014-11-24 16:28:03', 1),
('mvr', 'mvrSmolqn', 0, 2, '2014-11-24 15:35:52', 1),
('mvr', 'mvrSmolqnIzdirvani', 0, 2, '2014-11-24 15:35:47', 1),
('mvr', 'mvrSofiq', 0, 2, '2014-11-24 15:06:18', 1),
('mvr', 'mvrStaraZagora', 0, 2, '2014-11-24 15:06:16', 1),
('mvr', 'mvrStaraZagoraIzdirvani', 0, 2, '2014-11-24 15:35:47', 1),
('mvr', 'mvrTargovishte', 0, 2, '2014-11-24 15:35:48', 1),
('mvr', 'mvrHaskovo', 0, 2, '2014-11-24 15:35:49', 1),
('mvr', 'mvrShumen', 0, 2, '2014-11-24 16:40:11', 1),
('mvr', 'mvrShumenIzdirvani', 0, 2, '2014-11-24 15:35:49', 1),
('mvr', 'mvrQmbol', 0, 2, '2014-11-24 15:35:50', 1),
('mvr', 'mvrQmbolIzdirvani', 0, 2, '2014-11-24 16:40:11', 1),
('retweet', 'retweetAccounts', 0, 1, '2014-11-24 16:44:27', 1),
('mvr', 'mvrBurgas', 0, 2, '2014-11-24 15:35:50', 1),
('mvr', 'mvrPlovdiv', 0, 2, '2014-11-24 16:40:11', 1),
('min_mi', 'mi_Obsajdane', 0, 3, '2014-09-09 18:20:03', 0),
('min_mi', 'mi_Makrobiuletin', 0, 26, '2014-11-24 06:39:04', 1),
('min_mi', 'mi_Fininst', 0, 48, '2014-11-23 23:52:05', 1),
('min_mi', 'mi_KoncentraciqFin', 0, 48, '2014-11-24 00:13:03', 1),
('min_mh', 'mh_Saobshteniq', 0, 1, '2014-11-24 16:27:57', 1),
('min_mh', 'mh_Novini', 0, 1, '2014-11-24 16:27:56', 1),
('kfn', 'kfn_Novini', 0, 0, NULL, 1),
('kfn', 'kfn_Analizi', 0, 4, '2014-11-24 16:40:02', 1),
('min_mh', 'mh_Normativni', 0, 6, '2014-11-24 12:30:08', 1),
('min_mh', 'mh_Naredbi', 0, 6, '2014-11-24 12:30:06', 1),
('min_mh', 'mh_Otcheti', 0, 6, '2014-11-24 12:30:05', 1),
('min_mh', 'mh_Postanovleniq', 0, 6, '2014-11-24 12:30:04', 1),
('nap', 'napAktualno', 0, 0, NULL, 1),
('parliament', 'parlKomisii', 0, 24, '2014-11-23 18:00:04', 1),
('parliament', 'parlKomisiiZasedaniq', 0, 4, '2014-11-24 14:00:04', 1),
('parliament', 'parlKomisiiNovini', 0, 4, '2014-11-24 14:00:05', 1),
('parliament', 'parlKomisiiDokumenti', 0, 4, '2014-11-24 14:00:04', 1),
('parliament', 'parlKomisiiDokladi', 0, 4, '2014-11-24 14:00:04', 1),
('parliament', 'parlKomisiiStenogrami', 0, 4, '2014-11-24 14:00:05', 1),
('government', 'govNovini2', 0, 0, NULL, 1),
('government', 'govPorachki', 0, 3, '2014-11-24 14:01:20', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
